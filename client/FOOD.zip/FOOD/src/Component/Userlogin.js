import React,{ Fragment,useEffect,useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { Button,Container,Form,FormGroup, Input } from "reactstrap";

const Userlogin=()=>{
    
    
    const navigate =useNavigate();
    useEffect(()=>{
        document.title="Login || Food Delivery";
    },[]);
    
 function handleClick(){
    navigate("/Registration")
 }
    return(
        <Fragment>
            <h2>User Login</h2>
            <form>
                <FormGroup>
                    <label for="email">Username</label>
                    <Input
                        type="text"
                        placeholder="Enter email"
                        name="email"
                        Id="email"
                       
                        />
                         </FormGroup>
                         <FormGroup>
                    <label for="Password">Password</label>
                    <Input
                        type="text"
                        placeholder="Enter Passsword"
                        name="password"
                        Id="Password"
                        />
                        
                </FormGroup>

               
               
                    <Container className="text-center">
                    <Button type="submit" color="success" href="/AllCategoery">Login</Button>{' '}
                    <Button onClick={handleClick}>Registration</Button>
             
                    
                </Container>
            </form>
        </Fragment>
    );
};



export default Userlogin;