import React,{ Fragment,useEffect,useState } from "react";
import { Button,Container,Form,FormGroup, Input } from "reactstrap";
const Registration=()=>{
    
    const [firstname,setFirstname]=useState(" ");
    const [lastname,setLastname]=useState(" ");
    const [email,setEmail]=useState(" ");
    const [mobileno,setMobileNo]=useState(" ");
    const [password,setPassword]=useState(" ");
    const collectData=  ()=>{
        console.log(firstname,lastname,email,mobileno,password);
        //   console.warn(id,firstname,lastname,email,mobileno,password);
        //   let result= await fetch("http://localhost:7075/user",{
        //      method:'post',
        //       body:JSON.stringify({firstname,lastname,email,mobileno,password}),
        //       headers:{
        //           'Content-Type':'application/json'
        //       }
        //   });
        //   result=await result.json();
        //   console.warn(result);
        //   localStorage.setItem("user",JSON.stringify(result));
    }
    useEffect(()=>{
        document.title="Registration || Food Delivery";
    },[]);
    return(
        <Fragment>
            <h2>Registration</h2>
            <form>
           
                <FormGroup>
                    <label for="Firstname">First Name</label>
                    <Input
                        type="text"
                        placeholder="Enter First Name"
                        name="firstname"
                        id="FirstName"
                        onChange={(e)=>{
                            setFirstname(e.target.value)
                        }}
                        />
                         </FormGroup>
                         <FormGroup>
                    <label for="Lastname">Last Name</label>
                    <Input
                        type="text"
                        placeholder="Enter Last Name"
                        name="lastname"
                        id="LastName"
                        onChange={(e)=>{
                            setLastname(e.target.value)
                        }}
                        />
                         </FormGroup>
                        

               
                         <FormGroup>
                    <label for="Email">Email</label>
                    <Input
                        type="text"
                        placeholder="Email Address"
                        name="email"
                        Id="Email"
                        onChange={(e)=>{
                            setEmail(e.target.value)
                        }}
                        />
                        
                </FormGroup>
                <FormGroup>
                    <label for="Mobileno">Mobile No</label>
                    <Input
                        type="text"
                        placeholder="Enter Mobile No"
                        name="mobileno"
                        id="Mobileno" onChange={(e)=>{
                            setMobileNo(e.target.value)
                        }}
                        />
                    
                        
                </FormGroup>
                <FormGroup>
                    <label for="Password">Password</label>
                    <Input
                        type="text"
                        placeholder="Enter Passsword"
                        name="password"
                        Id="Password"
                        onChange={(e)=>{
                            setPassword(e.target.value);
                        }}
                        />
                        
                </FormGroup>
                <Container className="text-center">
                    <Button onClick={collectData} color="success" href="/user-login">Register</Button>
                    
                </Container>
            </form>
        </Fragment>
    );
};



export default Registration;